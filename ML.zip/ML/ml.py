from flask import Flask, request, render_template_string, url_for, send_file
import pandas as pd
import joblib
import os
import webbrowser
from threading import Timer
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import io
from collections import Counter

app = Flask(__name__)

# File Paths
TRANSACTIONS_FILE = r"C:\Users\DELL\Downloads\ML\transactions_sample.csv"
MODEL_FILE = "fraud_model.pkl"
ENCODERS_FILE = "label_encoders.pkl"

# Load Data
def load_data():
    if not os.path.exists(TRANSACTIONS_FILE):
        return None
    return pd.read_csv(TRANSACTIONS_FILE)

# Load Model
if os.path.exists(MODEL_FILE) and os.path.exists(ENCODERS_FILE):
    model = joblib.load(MODEL_FILE)
    label_encoders = joblib.load(ENCODERS_FILE)
else:
    model, label_encoders = None, None

# Store predictions (temporary in-memory storage)
prediction_history = []

# Encode Labels
def safe_encode(encoder, value):
    return encoder.transform([value])[0] if value in encoder.classes_ else -1

# Generate Bar Chart
def generate_chart():
    # Extract only the 'fraud' values from prediction_history
    fraud_values = [entry['fraud'] for entry in prediction_history]
    counts = Counter(fraud_values)
    valid_count = counts.get(0, 0)  # 0 represents valid
    fraud_count = counts.get(1, 0)  # 1 represents fraud

    fig, ax = plt.subplots()
    ax.bar(['Valid', 'Fraud'], [valid_count, fraud_count], color=['green', 'red'])
    ax.set_title('Transaction Fraud vs Valid Count')
    ax.set_ylabel('Number of Transactions')
    plt.tight_layout()

    # Save to a BytesIO object
    img = io.BytesIO()
    plt.savefig(img, format='png', bbox_inches='tight')
    plt.close(fig)
    img.seek(0)
    return img

# Home Page
@app.route('/')
def index():
    return render_template_string('''
    <html>
    <head>
        <title>Transaction Fraud Detection</title>
        <style>
            body {
                text-align: center;
                background-image: url("{{ url_for('static', filename='image1.jpg') }}");
                background-size: cover;
                background-position: center;
                font-family: Arial, sans-serif;
                color: white;
            }
            .container {
                background: rgba(44, 62, 80, 0.9);
                padding: 30px;
                border-radius: 10px;
                width: 40%;
                margin: auto;
                margin-top: 100px;
                box-shadow: 0px 0px 20px rgba(255, 255, 255, 0.3);
            }
            input, button {
                padding: 12px;
                margin: 10px;
                width: 85%;
                border-radius: 5px;
                border: none;
                font-size: 16px;
            }
            button {
                background: #F1C40F;
                color: black;
                cursor: pointer;
                font-weight: bold;
            }
            button:hover {
                background: #D4AC0D;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h2>Check Transaction Fraud</h2>
            <form action="/transaction_details" method="POST">
                <input type="text" name="bank_ref_no" placeholder="Enter Bank Ref No" required>
                <button type="submit">Check Transaction</button>
            </form>
        </div>
    </body>
    </html>
    ''')

# Transaction Details Page
@app.route('/transaction_details', methods=['POST'])
def transaction_details():
    bank_ref_no = request.form['bank_ref_no']
    df = load_data()

    if df is None or 'Bank Ref. No.' not in df.columns:
        return "Error: Transactions file not found."

    try:
        bank_ref_no = int(bank_ref_no)
    except ValueError:
        return "Error: Invalid Bank Ref No format."

    transaction = df[df['Bank Ref. No.'] == bank_ref_no]
    if transaction.empty:
        return render_template_string('''
        <html>
        <head>
            <title>Transaction Not Found</title>
            <style>
                body {
                    text-align: center;
                    background: #B0BEC5;
                    font-family: Arial, sans-serif;
                    color: black;
                }
                .container {
                    background: white;
                    padding: 30px;
                    border-radius: 10px;
                    width: 50%;
                    margin: auto;
                    margin-top: 100px;
                    box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3);
                }
                h2 {
                    color: red;
                    font-size: 22px;
                }
                .check-another {
                    display: inline-block;
                    margin-top: 15px;
                    padding: 12px 20px;
                    font-size: 16px;
                    background: #F1C40F;
                    color: black;
                    font-weight: bold;
                    text-decoration: none;
                    border-radius: 5px;
                }
                .check-another:hover { background: #D4AC0D; }
            </style>
        </head>
        <body>
            <div class="container">
                <h2>No transaction found for Bank Ref No: {{ bank_ref_no }}</h2>
                <a href="/" class="check-another">Check Another</a>
            </div>
        </body>
        </html>
        ''', bank_ref_no=bank_ref_no)

    transaction_data = transaction.iloc[0].to_dict()
    
    # Encode Labels
    bank_encoded = safe_encode(label_encoders["Bank"], transaction_data["Bank"])
    txn_status_encoded = safe_encode(label_encoders["Txn Status"], transaction_data["Txn Status"])
    
    # Predict Fraud Status
    features = [[transaction_data["Bank Ref. No."], transaction_data["Amount"], bank_encoded, txn_status_encoded]]
    fraud_prediction = model.predict(features)[0]
    fraud_status = "Fraudulent Transaction" if fraud_prediction == 1 else "Valid Transaction"
    fraud_status_color = "red" if fraud_prediction == 1 else "green"

    # Store prediction (avoid duplicates by checking if Bank Ref No already exists)
    if bank_ref_no not in [t['Bank Ref. No.'] for t in prediction_history]:
        prediction_history.append({'Bank Ref. No.': bank_ref_no, 'fraud': fraud_prediction})

    return render_template_string('''
    <html>
    <head>
        <title>Transaction Details</title>
        <style>
            body {
                text-align: center;
                background: #B0BEC5;
                font-family: Arial, sans-serif;
                color: black;
            }
            .container {
                background: white;
                padding: 30px;
                border-radius: 10px;
                width: 50%;
                margin: auto;
                margin-top: 100px;
                box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.3);
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-top: 20px;
                color: black;
                border-radius: 8px;
                overflow: hidden;
            }
            th, td {
                padding: 12px;
                border-bottom: 1px solid #ddd;
                text-align: left;
                color: black;
            }
            th {
                background: #2C3E50;
                color: white;
                text-transform: uppercase;
            }
            tr:nth-child(even) { background-color: #ECF0F1; }
            tr:nth-child(odd) { background-color: #D5DBDB; }
            h2 { color: {{ fraud_status_color }}; }
            .check-another, .view-graph {
                display: inline-block;
                margin-top: 15px;
                padding: 12px 20px;
                font-size: 16px;
                background: #F1C40F;
                color: black;
                font-weight: bold;
                text-decoration: none;
                border-radius: 5px;
                margin-right: 10px;
            }
            .check-another:hover, .view-graph:hover { background: #D4AC0D; }
        </style>
    </head>
    <body>
        <div class="container">
            <h2 style="color: {{ fraud_status_color }};">{{ fraud_status }}</h2>
            <table>
                <tr><th>Bank Ref. No.</th><td>{{ transaction['Bank Ref. No.'] }}</td></tr>
                <tr><th>Date</th><td>{{ transaction['Date'] }}</td></tr>
                <tr><th>Time</th><td>{{ transaction['Time'] }}</td></tr>
                <tr><th>Bank</th><td>{{ transaction['Bank'] }}</td></tr>
                <tr><th>Amount</th><td>₹{{ transaction['Amount'] }}</td></tr>
                <tr><th>Txn Status</th><td>{{ transaction['Txn Status'] }}</td></tr>
            </table>
            <br>
            <a href="/" class="check-another">Check Another</a>
            <a href="/graph" class="view-graph">View Graph</a>
        </div>
    </body>
    </html>
    ''', transaction=transaction_data, fraud_status=fraud_status, fraud_status_color=fraud_status_color)

# Graph Page
@app.route('/graph')
def graph():
    img = generate_chart()
    return send_file(img, mimetype='image/png')

if __name__ == '__main__':
    if os.environ.get("WERKZEUG_RUN_MAIN") == "true":
        Timer(1, lambda: webbrowser.open("http://127.0.0.1:5000/")).start()
    app.run(debug=True)